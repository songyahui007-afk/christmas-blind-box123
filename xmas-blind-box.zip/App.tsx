import React, { useState, useEffect, useCallback } from 'react';
import { BlindBoxCard } from './components/BlindBoxCard';
import Snowfall from './components/Snowfall';
import { generateBlindBoxContent } from './services/geminiService';
import { db } from './services/db';
import { AdminDashboard } from './components/AdminDashboard';
import { BlindBoxData, GameState, BlindBoxRecord } from './types';
import { Info, Sparkles, TreePine, Gift, Share2, Copy, Link as LinkIcon, LockKeyhole } from 'lucide-react';
import { ROLES_LIST } from './data/roles';

const STORAGE_KEY = 'xmas_blind_box_selection_v3';

const App: React.FC = () => {
  const [gameState, setGameState] = useState<GameState>(GameState.IDLE);
  const [mySelection, setMySelection] = useState<BlindBoxData | null>(null);
  const [loadingId, setLoadingId] = useState<number | null>(null);
  const [takenIds, setTakenIds] = useState<Set<number>>(new Set());
  const [showAdmin, setShowAdmin] = useState(false);

  // Initial Load
  useEffect(() => {
    // 1. Load User's local choice
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved) {
      try {
        setMySelection(JSON.parse(saved));
        setGameState(GameState.REVEALED);
      } catch (e) {
        localStorage.removeItem(STORAGE_KEY);
      }
    }

    // 2. Load Global taken state from DB
    refreshTakenState();
  }, []);

  const refreshTakenState = async () => {
    try {
      const taken = await db.getTakenBoxes();
      setTakenIds(new Set(taken.map(t => t.id)));
    } catch (e) {
      console.error("Failed to sync DB", e);
    }
  };

  const handleOpenBox = useCallback(async (roleItem: typeof ROLES_LIST[0]) => {
    // Prevent if already selected or if box is taken by someone else
    if (mySelection) return;
    if (takenIds.has(roleItem.id)) {
      alert("哎呀！这个盲盒已经被别人抢先一步挑走了，换一个吧！");
      await refreshTakenState(); // Sync just in case
      return;
    }

    setLoadingId(roleItem.id);
    setGameState(GameState.OPENING);

    try {
      let finalData: BlindBoxData;

      // Logic:
      // 1. If BOTH content and buff exist in CSV, use them immediately.
      // 2. If EITHER is missing, call Gemini. 
      //    Pass 'content' (Wish) if it exists so Gemini preserves it.

      if (roleItem.content && roleItem.buff) {
        // Fast path: All data exists
        finalData = {
          id: roleItem.id,
          role: roleItem.role,
          content: roleItem.content,
          buff: roleItem.buff,
          openedAt: new Date().toISOString(),
        };
        // Fake a small delay for dramatic effect if it's instant
        await new Promise(r => setTimeout(r, 800)); 
      } else {
        // Generation path
        const generated = await generateBlindBoxContent(roleItem.role, roleItem.content);
        
        finalData = {
          id: roleItem.id,
          role: roleItem.role, 
          content: roleItem.content || generated.content, 
          buff: roleItem.buff || generated.buff,
          openedAt: new Date().toISOString(),
        };
      }

      // 3. Try to save to DB (Global Lock)
      const success = await db.saveSelection(finalData);
      
      if (!success) {
        throw new Error("ALREADY_TAKEN");
      }

      // 4. Save to Local (Personal persistence)
      localStorage.setItem(STORAGE_KEY, JSON.stringify(finalData));
      
      setMySelection(finalData);
      setTakenIds(prev => new Set(prev).add(finalData.id));
      setGameState(GameState.REVEALED);

    } catch (error: any) {
      console.error("Error", error);
      if (error.message === "ALREADY_TAKEN") {
        alert("太慢啦！刚才的一瞬间被别人抢走了😭");
        await refreshTakenState();
      } else {
        setGameState(GameState.ERROR);
        alert("网络开小差了，请再试一次！");
      }
    } finally {
      setLoadingId(null);
    }
  }, [mySelection, takenIds]);

  const handleCopyResult = () => {
    if (!mySelection) return;
    const text = `🎄 圣诞盲盒派对 \n✨ 我抽到了：${mySelection.role}\n📝 愿望：${mySelection.content}\n🎁 Buff：${mySelection.buff}\n\n快来看看你抽到了什么！`;
    navigator.clipboard.writeText(text).then(() => {
      alert("🎁 结果已复制！快去分享给朋友吧~");
    }).catch(() => {
      alert("复制失败，请截图分享");
    });
  };

  const handleCopyLink = () => {
    navigator.clipboard.writeText(window.location.href).then(() => {
      alert("🔗 链接已复制！");
    }).catch(() => {
      alert("复制失败");
    });
  };

  return (
    <div className="min-h-screen flex flex-col items-center relative z-10 font-sans pb-20 bg-[#2d0a0a] overflow-x-hidden">
      {showAdmin && <AdminDashboard onClose={() => setShowAdmin(false)} />}
      
      <Snowfall />
      
      {/* Decorative Background Elements */}
      <div className="fixed bottom-0 left-0 text-green-900/20 -z-10 pointer-events-none transform -translate-x-10 translate-y-10">
         <TreePine size={300} strokeWidth={1} />
      </div>
      <div className="fixed bottom-0 right-0 text-red-900/20 -z-10 pointer-events-none transform translate-x-10 translate-y-10">
         <Gift size={250} strokeWidth={1} />
      </div>
      
      {/* Header */}
      <header className="w-full text-center py-10 px-4 z-20 bg-gradient-to-b from-black/60 to-transparent sticky top-0 backdrop-blur-sm border-b border-white/5 shadow-sm relative group">
        <h1 className="text-4xl md:text-6xl font-black text-transparent bg-clip-text bg-gradient-to-r from-yellow-200 via-red-400 to-yellow-200 drop-shadow-[0_2px_4px_rgba(0,0,0,0.8)] tracking-tight font-serif">
          圣诞盲盒派对
        </h1>
        <p className="text-yellow-100/90 mt-3 text-sm md:text-base max-w-lg mx-auto font-medium drop-shadow-md">
          {mySelection 
            ? "✨ 你的命运已揭晓！ ✨" 
            : "挑选一张角色卡，揭开属于你的圣诞 Buff！"}
        </p>
        
        {/* Hidden Admin Trigger (Double click title area or click invisible button) */}
        <button 
           onClick={() => setShowAdmin(true)}
           className="absolute top-2 right-2 text-white/5 hover:text-white/20 transition-colors p-2"
           title="管理员入口"
        >
          <LockKeyhole size={16} />
        </button>
      </header>

      {/* Main Content */}
      <main className="w-full max-w-6xl px-4 z-20 mt-8">
        
        {/* REVEALED STATE: Show user's card prominently with Share Actions */}
        {mySelection && (
          <div className="mb-12 flex flex-col items-center animate-fade-in-up">
            <div className="text-yellow-300 font-bold mb-6 text-xl flex items-center gap-2 bg-black/40 px-8 py-3 rounded-full border border-yellow-500/50 shadow-[0_0_25px_rgba(253,224,71,0.2)]">
               <Sparkles className="animate-pulse" /> 你的专属身份卡 <Sparkles className="animate-pulse" />
            </div>
            
            <div className="w-80 md:w-96 transform hover:scale-[1.02] transition-transform duration-500 shadow-2xl">
               <BlindBoxCard 
                 id={mySelection.id}
                 roleName={mySelection.role}
                 isRevealed={true}
                 isLocked={false}
                 data={mySelection}
                 isLoading={false}
                 onOpen={() => {}}
               />
            </div>

            {/* Share Actions */}
            <div className="flex gap-4 mt-8">
              <button 
                onClick={handleCopyResult}
                className="flex items-center gap-2 bg-green-700 hover:bg-green-600 text-white px-6 py-3 rounded-full font-bold shadow-lg transform transition active:scale-95 border border-green-400/30"
              >
                <Copy size={18} />
                复制结果
              </button>
              <button 
                onClick={handleCopyLink}
                className="flex items-center gap-2 bg-red-700 hover:bg-red-600 text-white px-6 py-3 rounded-full font-bold shadow-lg transform transition active:scale-95 border border-red-400/30"
              >
                <LinkIcon size={18} />
                复制链接
              </button>
            </div>

            <div className="mt-8">
              <button 
                onClick={() => {
                  if(confirm("确定要重置吗？这将清除你的选择记录。（仅用于测试）")) {
                    localStorage.removeItem(STORAGE_KEY);
                    window.location.reload();
                  }
                }}
                className="text-[10px] text-white/30 hover:text-white hover:underline transition-colors uppercase tracking-widest"
              >
                [重置抽奖 - 测试用]
              </button>
            </div>
          </div>
        )}

        {/* GRID STATE - Displaying only the 12 items */}
        <div className={`grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4 md:gap-6 ${mySelection ? 'opacity-30 pointer-events-none filter grayscale blur-[1px]' : ''} transition-all duration-700`}>
          {ROLES_LIST.map((item) => {
             // Logic:
             // 1. If I selected this, it is REVEALED.
             // 2. If I have NOT selected anything yet, but it is in takenIds, it is LOCKED (Taken by others).
             // 3. Otherwise it is openable.

             const isMySelection = mySelection?.id === item.id;
             const isTakenByOthers = !mySelection && takenIds.has(item.id);
             
             return (
               <BlindBoxCard
                 key={item.id}
                 id={item.id}
                 roleName={item.role}
                 isRevealed={isMySelection}
                 isLocked={isTakenByOthers} // Lock if taken by someone else
                 isTakenByOthers={isTakenByOthers} // Pass visual flag
                 data={isMySelection ? mySelection! : undefined}
                 isLoading={loadingId === item.id}
                 onOpen={() => handleOpenBox(item)}
               />
             );
          })}
        </div>
      </main>

      <footer className="mt-16 pb-8 text-center text-white/40 text-xs px-4">
        <div className="flex items-center justify-center gap-1 mb-2">
           <Info size={14} />
           <span>每人仅限翻牌一次，手慢无！</span>
        </div>
        <p className="font-mono opacity-50">Merry Christmas & Happy New Year</p>
      </footer>
    </div>
  );
};

export default App;