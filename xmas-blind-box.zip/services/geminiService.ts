import { GoogleGenAI, Type, Schema } from "@google/genai";
import { GeneratedContent } from "../types";

// Schema for the blind box content
const blindBoxSchema: Schema = {
  type: Type.OBJECT,
  properties: {
    role: {
      type: Type.STRING,
      description: "The name of the character.",
    },
    content: {
      type: Type.STRING,
      description: "The wish or content associated with the role.",
    },
    buff: {
      type: Type.STRING,
      description: "A creative 'buff' or condition the user must follow.",
    },
  },
  required: ["role", "content", "buff"],
};

export const generateBlindBoxContent = async (roleName: string, existingWish?: string): Promise<GeneratedContent> => {
  try {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    
    let prompt = `
      You are the game master for a Christmas Party Blind Box event.
      The user has selected the role: "${roleName}".
      
      Language: Chinese (Simplified).
    `;

    if (existingWish) {
      prompt += `
      The user has ALREADY made a specific wish: "${existingWish}".
      
      Your task:
      1. 'content': Return the user's wish exactly as provided above. Do not change it.
      2. 'buff': Generate a fun, creative party 'buff' (condition/rule) that matches this specific wish and role.
      `;
    } else {
      prompt += `
      Please generate the 'content' (wish/quote) and 'buff' (party rule) for this specific role.
      
      Requirements:
      1. Content: A classic line, poem, or funny description fitting for ${roleName}.
      2. Buff: A fun, harmless social interaction rule or constraint for a party setting inspired by ${roleName}.
      `;
    }

    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: blindBoxSchema,
        temperature: 1.0, 
      },
    });

    if (response.text) {
        return JSON.parse(response.text) as GeneratedContent;
    }
    
    throw new Error("No content generated");

  } catch (error) {
    console.error("Gemini generation error:", error);
    // Fallback
    return {
      role: roleName,
      content: existingWish || "系统繁忙，但你的运气依然爆棚！",
      buff: "万能卡：你可以指定任意规则。"
    };
  }
};