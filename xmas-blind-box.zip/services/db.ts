import { createClient } from '@supabase/supabase-js';
import { BlindBoxData, BlindBoxRecord } from '../types';

// Helper function to safely access environment variables in different environments (Vite, Node, etc.)
const getEnv = (key: string) => {
  // Check for Vite's import.meta.env
  // @ts-ignore
  if (typeof import.meta !== 'undefined' && import.meta.env) {
    // @ts-ignore
    return import.meta.env[key] || '';
  }
  // Check for Node's process.env
  if (typeof process !== 'undefined' && process.env) {
    return process.env[key] || '';
  }
  return '';
};

// Retrieve keys safely
const SUPABASE_URL = getEnv('VITE_SUPABASE_URL');
const SUPABASE_KEY = getEnv('VITE_SUPABASE_ANON_KEY');

const isSupabaseConfigured = !!(SUPABASE_URL && SUPABASE_KEY);

let supabase: any = null;
if (isSupabaseConfigured) {
  try {
    supabase = createClient(SUPABASE_URL, SUPABASE_KEY);
    console.log("Supabase client initialized");
  } catch (e) {
    console.error("Failed to initialize Supabase client:", e);
  }
} else {
  console.warn("Supabase is NOT configured. Falling back to local storage.");
}

const LOCAL_STORAGE_ALL_KEY = 'xmas_all_records_dev';

export const db = {
  /**
   * Check if the database is effectively connected
   */
  isOnline: () => isSupabaseConfigured,

  /**
   * Get all records (taken boxes)
   */
  async getTakenBoxes(): Promise<BlindBoxRecord[]> {
    if (isSupabaseConfigured && supabase) {
      const { data, error } = await supabase
        .from('blind_boxes')
        .select('*');
      if (error) {
        console.error("DB Fetch Error", error);
        return [];
      }
      return data || [];
    } else {
      // Fallback: Read from local storage simulation
      const saved = localStorage.getItem(LOCAL_STORAGE_ALL_KEY);
      return saved ? JSON.parse(saved) : [];
    }
  },

  /**
   * Check if a specific box ID is taken
   */
  async isBoxTaken(id: number): Promise<boolean> {
    const boxes = await this.getTakenBoxes();
    return boxes.some(b => b.id === id);
  },

  /**
   * Save a selection
   */
  async saveSelection(data: BlindBoxData): Promise<boolean> {
    if (isSupabaseConfigured && supabase) {
      // 1. Double check if taken (prevent race condition)
      const isTaken = await this.isBoxTaken(data.id);
      if (isTaken) return false;

      // 2. Insert
      const { error } = await supabase
        .from('blind_boxes')
        .insert([data]);
      
      if (error) {
        console.error("DB Save Error", error);
        return false;
      }
      return true;
    } else {
      // Local Simulation
      const boxes = await this.getTakenBoxes();
      if (boxes.some(b => b.id === data.id)) return false;
      
      boxes.push(data);
      localStorage.setItem(LOCAL_STORAGE_ALL_KEY, JSON.stringify(boxes));
      return true;
    }
  },
  
  /**
   * ADMIN: Reset all data
   */
  async resetAll(): Promise<void> {
     if (isSupabaseConfigured && supabase) {
        // In a real app, this should be protected by RLS or server-side logic
        await supabase.from('blind_boxes').delete().neq('id', -1);
     } else {
        localStorage.removeItem(LOCAL_STORAGE_ALL_KEY);
     }
  }
};