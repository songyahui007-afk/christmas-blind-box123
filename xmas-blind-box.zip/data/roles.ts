export interface RoleDef {
  id: number;
  role: string;
  content?: string;
  buff?: string;
}

// User provided CSV Data
export const ROLES_LIST: RoleDef[] = [
  {
    id: 2,
    role: "变身一只鸟",
    content: "给我一双翅膀",
    buff: "必须是绿色"
  },
  {
    id: 3,
    role: "藏品幻师",
    content: "最想要的是隐藏款",
    buff: "许愿我打开的每一个数字或实体盲盒，都能直接抽中隐藏款！"
  },
  {
    id: 4,
    role: "戴黑框眼镜的青蛙",
    content: "作为一个长者时常头晕眼花，来个能为我续1s的东西是最坠吼的",
    // buff missing in CSV
  },
  {
    id: 5,
    role: "李白",
    content: "我想要：人生得意须尽欢，莫使金樽空对月",
    buff: "必须要是液体"
  },
  {
    id: 7,
    role: "爱睡觉的考拉",
    content: "每天睡得饱饱的，香香的",
    buff: "让人放松的"
  },
  {
    id: 8,
    role: "作为一名被 deadline 追杀的战士",
    content: "作为一名被 deadline 追杀的战士，我急需一位情绪极度稳定的新同事。它不需要会写周报，只需要有着 100% 的完美妆容，最好只有巴掌大小，能够静止在我电脑屏幕旁，用它那精致的沉默，替我向这个世界翻一个可爱的白眼。",
    // buff missing in CSV
  },
  {
    id: 9,
    role: "牛爷爷 张兴朝",
    content: "传统的礼物、好无趣、好无聊，我想要一个不那么传统的礼物",
    // buff missing in CSV
  },
  {
    id: 10,
    role: "光",
    content: "光可以到达任何事物，光可以触及任何事物，光可以记住任何事物，光可以将事物折射并转化为新的样子。如果变成光，我即可以看见万物，洞悉万物，并将我所知道的，了解的，再反馈给万物。",
    buff: "请自由想象和发挥～"
  },
  {
    id: 11,
    role: "颅内小剧场电影放映员",
    content: "作为颅内小剧场电影放映员，我需要屏蔽现实干扰信号的东西（圣诞特批版）。",
    buff: "包装好看点，我拍个照"
  },
  {
    id: 12,
    role: "有趣感性的夏洛克",
    content: "我和花生打造的温馨小花园",
    // buff missing in CSV
  },
  {
    id: 13,
    role: "豌豆公主",
    content: "午后在铺着蕾丝的窗边打盹时，总盼着有样小物，能让我不必紧绷神经去捕捉身下每一丝细微的差异 —— 它该像春风拂过绒草般轻软，却又藏着刚好的妥帖，让那些悄悄爬上来的肩颈酸意都被悄悄化开，连半梦半醒间的呼吸，都能慢下来变得更安稳些。",
    buff: "办公室生存用"
  },
  {
    id: 14,
    role: "雷淞然·雷砸",
    content: "“作为不长鹿茸的狍子，我需要一些麻药，因为我把狍子角掰下来了给藤根了，现在有点疼”",
    buff: "都可以"
  }
];