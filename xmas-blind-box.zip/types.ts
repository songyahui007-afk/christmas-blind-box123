export interface BlindBoxData {
  id: number;
  role: string;
  content: string;
  buff: string;
  openedAt: string; // ISO Date string
}

export interface BlindBoxRecord extends BlindBoxData {
  user_name?: string; // Optional: if we want to track who took it
}

export enum GameState {
  IDLE = 'IDLE',
  OPENING = 'OPENING',
  REVEALED = 'REVEALED',
  ERROR = 'ERROR'
}

export interface GeneratedContent {
  role: string;
  content: string;
  buff: string;
}