import React, { useEffect, useState } from 'react';
import { db } from '../services/db';
import { BlindBoxRecord } from '../types';
import { X, RefreshCw, Trash2, Database } from 'lucide-react';

interface AdminDashboardProps {
  onClose: () => void;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({ onClose }) => {
  const [password, setPassword] = useState('');
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [records, setRecords] = useState<BlindBoxRecord[]>([]);
  const [loading, setLoading] = useState(false);

  // Simple hardcoded password for the demo
  const ADMIN_PASS = "xmas2025";

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (password === ADMIN_PASS) {
      setIsAuthenticated(true);
      fetchRecords();
    } else {
      alert("密码错误");
    }
  };

  const fetchRecords = async () => {
    setLoading(true);
    try {
      const data = await db.getTakenBoxes();
      // Sort by open time desc
      data.sort((a, b) => new Date(b.openedAt).getTime() - new Date(a.openedAt).getTime());
      setRecords(data);
    } finally {
      setLoading(false);
    }
  };

  const handleReset = async () => {
    if (confirm("⚠️ 高危操作：确定要清空所有人的抽奖记录吗？此操作不可撤销！")) {
      await db.resetAll();
      await fetchRecords();
      alert("数据已清空");
    }
  };

  if (!isAuthenticated) {
    return (
      <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/90 backdrop-blur-md p-4">
        <div className="bg-white text-gray-900 p-8 rounded-xl shadow-2xl max-w-sm w-full relative">
          <button onClick={onClose} className="absolute top-2 right-2 text-gray-400 hover:text-gray-600">
            <X />
          </button>
          <h2 className="text-2xl font-bold mb-6 text-center">🎄 管理员登录</h2>
          <form onSubmit={handleLogin} className="space-y-4">
             <input 
               type="password" 
               value={password}
               onChange={(e) => setPassword(e.target.value)}
               placeholder="输入管理员密码"
               className="w-full px-4 py-3 border rounded-lg focus:ring-2 focus:ring-red-500 outline-none"
             />
             <button type="submit" className="w-full bg-red-600 hover:bg-red-700 text-white font-bold py-3 rounded-lg transition">
               进入后台
             </button>
             <p className="text-xs text-center text-gray-400 mt-4">默认密码: xmas2025</p>
          </form>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 z-50 bg-gray-100 text-gray-900 overflow-y-auto">
       <div className="max-w-6xl mx-auto p-4 md:p-8">
          <div className="flex justify-between items-center mb-8">
             <h2 className="text-3xl font-bold flex items-center gap-2">
               <Database className="text-red-600" />
               抽奖数据后台
             </h2>
             <button onClick={onClose} className="bg-gray-200 hover:bg-gray-300 p-2 rounded-full">
               <X />
             </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
             <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
                <div className="text-gray-500 text-sm mb-1">已抽取数量</div>
                <div className="text-4xl font-black text-red-600">{records.length}</div>
             </div>
             <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
                <div className="text-gray-500 text-sm mb-1">数据源状态</div>
                <div className="flex items-center gap-2">
                   <div className={`w-3 h-3 rounded-full ${db.isOnline() ? 'bg-green-500' : 'bg-yellow-500'}`}></div>
                   <span className="font-bold">{db.isOnline() ? 'Supabase 云端' : '本地模拟 (Local)'}</span>
                </div>
                {!db.isOnline() && <p className="text-xs text-orange-500 mt-1">仅当前浏览器可见，请配置 Vercel 环境变量以启用云端同步。</p>}
             </div>
          </div>

          <div className="bg-white rounded-xl shadow-lg overflow-hidden border border-gray-200">
             <div className="p-4 bg-gray-50 border-b flex justify-between items-center">
                <h3 className="font-bold text-gray-700">记录明细</h3>
                <div className="flex gap-2">
                   <button onClick={fetchRecords} className="flex items-center gap-1 text-sm bg-blue-50 text-blue-600 px-3 py-1.5 rounded hover:bg-blue-100">
                     <RefreshCw size={14} className={loading ? 'animate-spin' : ''} /> 刷新
                   </button>
                   <button onClick={handleReset} className="flex items-center gap-1 text-sm bg-red-50 text-red-600 px-3 py-1.5 rounded hover:bg-red-100">
                     <Trash2 size={14} /> 清空数据
                   </button>
                </div>
             </div>
             <div className="overflow-x-auto">
                <table className="w-full text-left text-sm">
                   <thead className="bg-gray-50 text-gray-500 uppercase tracking-wider">
                      <tr>
                         <th className="px-6 py-3 font-medium">编号</th>
                         <th className="px-6 py-3 font-medium">角色 (Role)</th>
                         <th className="px-6 py-3 font-medium">愿望 (Content)</th>
                         <th className="px-6 py-3 font-medium">Buff</th>
                         <th className="px-6 py-3 font-medium">抽取时间</th>
                      </tr>
                   </thead>
                   <tbody className="divide-y divide-gray-100">
                      {records.length === 0 ? (
                        <tr>
                           <td colSpan={5} className="px-6 py-12 text-center text-gray-400">暂无数据</td>
                        </tr>
                      ) : (
                        records.map((rec) => (
                           <tr key={rec.id} className="hover:bg-gray-50">
                              <td className="px-6 py-4 font-mono text-gray-400">#{rec.id}</td>
                              <td className="px-6 py-4 font-bold text-gray-800">{rec.role}</td>
                              <td className="px-6 py-4 text-gray-600 max-w-xs truncate" title={rec.content}>{rec.content}</td>
                              <td className="px-6 py-4 text-red-600 font-medium max-w-xs truncate" title={rec.buff}>{rec.buff}</td>
                              <td className="px-6 py-4 text-gray-400 text-xs">
                                {new Date(rec.openedAt).toLocaleString('zh-CN')}
                              </td>
                           </tr>
                        ))
                      )}
                   </tbody>
                </table>
             </div>
          </div>
       </div>
    </div>
  );
};