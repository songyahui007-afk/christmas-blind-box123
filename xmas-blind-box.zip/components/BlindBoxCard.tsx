import React, { useMemo } from 'react';
import { Gift, Lock, Sparkles, UserX } from 'lucide-react';
import { BlindBoxData } from '../types';

interface BlindBoxCardProps {
  id: number;
  roleName: string; 
  isRevealed: boolean;
  isLocked: boolean;
  isTakenByOthers?: boolean;
  data?: BlindBoxData;
  isLoading: boolean;
  onOpen: () => void;
}

export const BlindBoxCard: React.FC<BlindBoxCardProps> = ({
  id,
  roleName,
  isRevealed,
  isLocked,
  isTakenByOthers,
  data,
  isLoading,
  onOpen,
}) => {
  
  const handleClick = () => {
    if (isRevealed || isLocked || isLoading) return;
    onOpen();
  };

  // Generate a consistent seed-based image URL for the role
  // Using pollination.ai for dynamic placeholder generation
  const coverImageUrl = useMemo(() => {
    // Sanitize role name for URL
    const safeRole = encodeURIComponent(roleName);
    // Prompt: Christmas style, cute 3d render of [Role], festive background
    return `https://image.pollinations.ai/prompt/Christmas%20toy%20figurine%20of%20${safeRole}%20cute%20chibi%203d%20render%20festive%20lighting%20high%20quality?width=400&height=560&nologo=true&seed=${id}`;
  }, [roleName, id]);

  return (
    <div 
      className={`relative w-full aspect-[3/4.5] perspective-1000 cursor-pointer group ${isLocked ? 'cursor-not-allowed' : 'hover:scale-[1.02]'} transition-all duration-300`}
      onClick={handleClick}
    >
      <div 
        className={`w-full h-full relative transform-style-3d transition-transform duration-700 shadow-2xl rounded-xl ${isRevealed ? 'rotate-y-180' : ''}`}
      >
        {/* FRONT SIDE (Role Cover with Generated Image) */}
        <div className={`absolute w-full h-full backface-hidden bg-gray-900 rounded-xl overflow-hidden border-[3px] border-yellow-500/30 ${isLocked ? 'grayscale opacity-70' : ''}`}>
          
          {/* Generated Image Background */}
          <div className="absolute inset-0 bg-gray-800">
             <img 
               src={coverImageUrl} 
               alt={roleName}
               className="w-full h-full object-cover opacity-90 transition-transform duration-700 group-hover:scale-110"
               loading="lazy"
             />
             {/* Gradient Overlay for text readability */}
             <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/20 to-black/30"></div>
          </div>

          {/* Card Content Overlay */}
          <div className="absolute inset-0 flex flex-col justify-between p-3 z-10">
             {/* Header */}
             <div className="flex justify-between items-start">
               <span className="text-xs font-mono text-yellow-300 bg-black/50 px-2 py-1 rounded backdrop-blur-sm border border-yellow-500/30">
                 No.{id}
               </span>
               {isLocked && <Lock className="text-white/60 w-5 h-5" />}
             </div>

             {/* Footer Info */}
             <div className="flex flex-col items-center">
                {isLoading ? (
                   <div className="animate-spin text-yellow-300 mb-4">
                     <Sparkles size={32} />
                   </div>
                ) : (
                  <div className="text-center w-full">
                    <h3 className="text-yellow-100 font-black text-xl md:text-2xl leading-tight drop-shadow-[0_2px_2px_rgba(0,0,0,0.8)] mb-2 px-1">
                      {roleName}
                    </h3>
                    
                    {isTakenByOthers ? (
                      <div className="inline-flex items-center gap-1 text-[10px] uppercase tracking-widest text-red-300 bg-red-900/80 px-3 py-1 rounded-full backdrop-blur-md border border-red-500/30">
                        <UserX size={10} />
                        <span>已被抢走</span>
                      </div>
                    ) : !isLocked && (
                      <div className="inline-flex items-center gap-1 text-[10px] uppercase tracking-widest text-green-300 bg-green-900/60 px-3 py-1 rounded-full backdrop-blur-md border border-green-500/30">
                        <Gift size={10} />
                        <span>点击开启</span>
                      </div>
                    )}
                  </div>
                )}
             </div>
          </div>
        </div>

        {/* BACK SIDE (Revealed Content) */}
        <div className="absolute w-full h-full backface-hidden rotate-y-180 bg-[#fffdf5] text-gray-900 rounded-xl overflow-hidden flex flex-col shadow-inner border-[6px] border-red-700">
          {data && (
            <div className="flex flex-col h-full relative">
              {/* Header Ribbon */}
              <div className="bg-red-700 text-yellow-100 text-center py-2 shrink-0 shadow-md z-10">
                 <h2 className="text-lg font-black tracking-wide line-clamp-1 px-2">{data.role}</h2>
              </div>

              {/* Scrollable Content Area */}
              <div className="flex-1 overflow-y-auto p-4 scrollbar-thin scrollbar-thumb-red-200 scrollbar-track-transparent">
                 <div className="mb-4">
                    <span className="text-[10px] font-bold text-red-500 uppercase tracking-wider block mb-1">
                      圣诞愿望
                    </span>
                    <p className="text-sm md:text-base text-gray-800 font-serif leading-relaxed italic border-l-2 border-red-300 pl-3">
                      "{data.content}"
                    </p>
                 </div>

                 <div className="bg-red-50 rounded-lg p-3 border border-red-100">
                    <div className="flex items-center gap-2 mb-1">
                      <Sparkles className="w-4 h-4 text-yellow-600" />
                      <span className="text-[10px] font-bold text-red-800 uppercase tracking-wider">
                        Buff 任务
                      </span>
                    </div>
                    <p className="text-xs md:text-sm text-red-900 font-bold leading-relaxed">
                      {data.buff}
                    </p>
                 </div>
              </div>

              {/* Decorative Footer */}
              <div className="h-2 bg-gradient-to-r from-red-700 via-green-700 to-red-700 shrink-0"></div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};