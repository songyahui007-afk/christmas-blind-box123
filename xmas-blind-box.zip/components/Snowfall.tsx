import React, { useEffect, useState } from 'react';

const Snowfall: React.FC = () => {
  const [flakes, setFlakes] = useState<number[]>([]);

  useEffect(() => {
    // Create a static number of flakes to avoid constant re-renders
    const newFlakes = Array.from({ length: 50 }, (_, i) => i);
    setFlakes(newFlakes);
  }, []);

  return (
    <div className="fixed inset-0 pointer-events-none z-0 overflow-hidden">
      {flakes.map((i) => (
        <div
          key={i}
          className="snowflake text-white opacity-50"
          style={{
            left: `${Math.random() * 100}vw`,
            animationDuration: `${5 + Math.random() * 10}s`,
            animationDelay: `-${Math.random() * 10}s`,
            fontSize: `${10 + Math.random() * 20}px`,
          }}
        >
          ❄
        </div>
      ))}
    </div>
  );
};

export default Snowfall;